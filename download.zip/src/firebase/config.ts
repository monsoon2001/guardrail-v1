export const firebaseConfig = {
  "projectId": "studio-280495602-92365",
  "appId": "1:2361569601:web:b8ef0c2332353acea971c0",
  "apiKey": "AIzaSyCcdVxRtQCXqXjlvy8QOqh4LMKy4uyuYd8",
  "authDomain": "studio-280495602-92365.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "2361569601"
};
